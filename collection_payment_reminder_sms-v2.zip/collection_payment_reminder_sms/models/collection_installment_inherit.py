from odoo import models, fields, api
import requests
import logging
from odoo.tools import html2plaintext

_logger = logging.getLogger(__name__)

try:
    from ethioqen.calendar_conversion import convert_gregorian_to_ethiopian
except ImportError:
    _logger.warning("The 'ethioqen' library is missing.")

class CollectionInstallment(models.Model):
    _inherit = 'collection.installment'

    # Tracks the progression of reminders
    reminder_stage = fields.Selection([
        ('0', 'No Reminders Sent'),
        ('1', 'First Reminder Sent'),
        ('2', 'Second Reminder Sent'),
        ('3', 'Third Reminder Sent')
    ], string="Reminder Stage", default='0', readonly=True, copy=False)

    def write(self, vals):
        res = super(CollectionInstallment, self).write(vals)

        # Skip if triggered by an internal loop
        if self.env.context.get('skip_thank_you_sms'):
            return res

        # 🌟 Check if any installment in this write is in the 'paid' state
        if vals.get('state') == 'paid' or any(rec.state == 'paid' for rec in self):
            for rec in self:
                if rec.state == 'paid':
                    
                    # 🌟 DUPLICATE GUARD: Check if we ALREADY sent/queued a thank-you SMS for this installment!
                    already_sent = self.env['collection.sms.log'].sudo().search_count([
                        ('installment_id', '=', rec.id),
                        ('message_stage', '=', 'thank_you'),
                        ('status', 'in', ['sent', 'delivered'])
                    ])
                    
                    if not already_sent:
                        template = self.env['collection.sms.template'].search([('template_type', '=', 'thank_you')], limit=1)
                        if template:
                            # Use context flag to prevent recursive loops
                            rec.with_context(skip_thank_you_sms=True)._send_sms_from_template(rec, template)
                            
        return res

    def _send_sms_api(self, mobile, message):
        """ Send SMS via AfroMessage API with URL Encoding and Callback injection """
        if not mobile:
            return False, "No mobile number provided", False
            
        try:
            mobile = mobile.replace(' ', '').replace('-', '').replace('+', '')     
            token = 'eyJhbGciOiJIUzI1NiJ9.eyJpZGVudGlmaWVyIjoiQ2JsdHB6dHRFNkNaR1BjZ2VHWjRidThDUzMyOXczNWMiLCJleHAiOjE5Mjk4NzE1NjYsImlhdCI6MTc3MjEwNTE2NiwianRpIjoiNDZiZjhiYWMtNjhiOS00NmMzLWFjZTctMGZkNDMyNTM5YjMxIn0.3XK4_j0brTi7DkzE37YNVponFjzXyJo5w0a7TAr-7_Y' # Your token
            sender = 'Temer RE'
            from_identifier = 'e80ad9d8-adf3-463f-80f4-7c4b39f7f164'
            
            # Make sure this matches your current running Ngrok URL!
            ngrok_domain = "https://f447-196-191-223-105.ngrok-free.app"
            callback_url = f"{ngrok_domain}/afromessage/callback"
            
            session = requests.Session()
            base_url = 'https://api.afromessage.com/api/send'
            headers = {'Authorization': 'Bearer ' + token}
            
            payload = {
                'from': from_identifier,
                'sender': sender,
                'to': mobile,
                'message': message,
                'callback': callback_url 
            }
            
            result = session.get(base_url, headers=headers, params=payload)
            
            if result.status_code == 200:
                json_response = result.json()
                if json_response.get('acknowledge') == 'success':
                    response_data = json_response.get('response', {})
                    
                    # 🌟 THE FIX: Prioritize 'message_id' with an underscore!
                    msg_id = (
                        response_data.get('message_id') or 
                        response_data.get('messageId') or 
                        response_data.get('id') or 
                        ''
                    )
                    
                    # Nested array fallback
                    if not msg_id and 'messages' in response_data and len(response_data['messages']) > 0:
                        msg_id = (
                            response_data['messages'][0].get('message_id') or 
                            response_data['messages'][0].get('messageId') or 
                            ''
                        )
                        
                    return True, "Success", msg_id
                else:
                    return False, f"API Error: {json_response}", False
            else:
                return False, f"HTTP Error: {result.status_code} - {result.text}", False
                
        except Exception as e:
            return False, str(e), False

    def _send_sms_from_template(self, installment, template):
        """ Helper method to format text and trigger API """
        site = installment.collection_id.property_id.site
        mapping = self.env['site.company.mapping.line'].sudo().search([('site_id', '=', site.id)], limit=1)
        company_name = mapping.company_id.name if mapping and mapping.company_id else self.env.company.name

        amount_str = "{:,.2f}".format(installment.amount_residual or installment.amount_total)
        due_date_str = str(installment.due_date) if installment.due_date else "N/A"
        
        due_date_ec_str = "N/A"
        if installment.due_date:
            try:
                from ethioqen.calendar_conversion import convert_gregorian_to_ethiopian
                y, m, d = convert_gregorian_to_ethiopian(installment.due_date.year, installment.due_date.month, installment.due_date.day)
                due_date_ec_str = f"{d:02d}/{m:02d}/{y}"
            except Exception:
                pass

        raw_html_message = template.body.format(
            company_name=company_name,
            amount=amount_str,
            due_date=due_date_str,
            due_date_ec=due_date_ec_str
        )

        clean_message_text = html2plaintext(raw_html_message)
        phone = installment.partner_id.mobile or installment.partner_id.phone
        
        success, response_msg, api_message_id = self._send_sms_api(phone, clean_message_text)
        status = 'sent' if success else 'failed'

        # Create the Log
        self.env['collection.sms.log'].create({
            'installment_id': installment.id,
            'message_body': clean_message_text,
            'status': status,
            'api_message_id': api_message_id,
            'error_message': response_msg if not success else False,
            'sender_id': self.env.user.id,
            'message_stage': template.template_type
        })

        # 🌟 CRITICAL FIX: Commit immediately so the webhook thread can see this record!
        if api_message_id:
            self.env.cr.commit()

        return success

    @api.model
    def _cron_send_automated_reminders(self):
        """ 
        Runs daily. Automatically sends 2nd and 3rd reminders if 1st was sent.
        """
        today = fields.Date.context_today(self)

        # --- 1. SECOND REMINDER (Due Today) ---
        second_template = self.env['collection.sms.template'].search([('template_type', '=', 'second')], limit=1)
        if second_template:
            # Installments that received the 1st reminder, are not paid, and are due TODAY
            installments_for_second = self.search([
                ('reminder_stage', '=', '1'),
                ('state', 'not in', ['paid', 'pending']),
                ('due_date', '=', today),
                ('collection_id.state', '=', 'active')
            ])
            for inst in installments_for_second:
                if inst._send_sms_from_template(inst, second_template):
                    inst.write({'reminder_stage': '2'})

        # --- 2. THIRD REMINDER (Overdue) ---
        third_template = self.env['collection.sms.template'].search([('template_type', '=', 'third')], limit=1)
        if third_template:
            # Installments that received the 2nd reminder, are not paid, and due date has PASSED
            installments_for_third = self.search([
                ('reminder_stage', '=', '2'),
                ('state', 'not in', ['paid', 'pending']),
                ('due_date', '<', today),
                ('collection_id.state', '=', 'active')
            ])
            for inst in installments_for_third:
                if inst._send_sms_from_template(inst, third_template):
                    inst.write({'reminder_stage': '3'})
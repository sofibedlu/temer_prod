from odoo import http, fields
from odoo.http import request
import logging
import json

_logger = logging.getLogger(__name__)

class AfroMessageCallback(http.Controller):

    @http.route('/afromessage/callback', type='http', auth='public', methods=['GET', 'POST'], csrf=False)
    def afromessage_delivery_report(self, **kwargs):
        _logger.info("AfroMessage Callback Received. Params: %s", kwargs)

        api_message_id = kwargs.get('message_id') or kwargs.get('messageId')
        delivery_status = kwargs.get('status', '').upper()
        description = kwargs.get('description', '')

        if api_message_id and delivery_status:
            sms_log = request.env['collection.sms.log'].sudo().search([('api_message_id', '=', api_message_id)], limit=1)
            
            if sms_log:
                new_state = sms_log.status
                
                if delivery_status == 'DELIVRD' or 'DELIVERED' in delivery_status:
                    new_state = 'delivered'
                elif delivery_status in ['REJECTD', 'UNDELIV', 'FAILED', 'EXPIRED']:
                    new_state = 'undelivered'
                elif delivery_status in ['QUEUED', 'ESME_ROK']:
                    new_state = 'sent'

                sms_log.write({
                    'status': new_state,
                    'error_message': f"Carrier Update: {delivery_status} ({description}) at {fields.Datetime.now()}"
                })
                
                # 🌟 NEW LOG: Confirms Odoo successfully linked and updated the DB!
                _logger.info("✅ SUCCESS: Updated SMS Log %s to status '%s'", sms_log.id, new_state)
            else:
                _logger.warning("❌ FAILED: Could not find SMS Log with AfroMessage ID: %s", api_message_id)
                
        return request.make_response(
            json.dumps({'status': 'success'}),
            headers=[('Content-Type', 'application/json')]
        )